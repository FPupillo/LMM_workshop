# LMM_Workshop
Description of the files
## helper functions
Functions used by the main scripts
### simulatedData.R
Function used to simulate data. 
## LMM_workshop.Rproj
R project file
### PPT_LMM.odp
Slides
### lmmworkshop.Rmd
R markdown file: to run the code step by step
### lmmworkshop.md
Markdown file: to show the code online
